# Databricks notebook source
dbutils.widgets.text("p_data_source", "Testing", "Data Source:")
data_source = dbutils.widgets.get("p_data_source")

# COMMAND ----------

# MAGIC %run "../includes/configurations"

# COMMAND ----------

# MAGIC %run "../includes/common_functions"

# COMMAND ----------

from pyspark.sql.types import StructType, StructField, StringType, IntegerType, DoubleType, FloatType
from pyspark.sql.functions import current_timestamp, lit

# COMMAND ----------

establish_sas_connection()

# COMMAND ----------

lap_times_schema = StructType([
    StructField( "raceId", IntegerType(), False),
    StructField( "driverId", IntegerType(), True),
    StructField( "lap", IntegerType(), True),
    StructField( "position", IntegerType(), True),
    StructField( "time", StringType(), True),
    StructField( "milliseconds", IntegerType(), True)
])

# COMMAND ----------

lap_times_df = spark.read.csv(f"{raw_folder_path}/lap_times", schema = lap_times_schema)

lap_times_df = lap_times_df.withColumnRenamed("raceId", "race_id") \
    .withColumnRenamed("driverId", "driver_id") \
    .withColumn("data_source", lit(data_source))

lap_times_df = add_ingestion_datetime(lap_times_df)

lap_times_df = lap_times_df.drop("statusId")

display(lap_times_df)
lap_times_df.count()

# COMMAND ----------

lap_times_df.write.mode("overwrite").parquet(f"{processed_folder_path}/lap_times")

# COMMAND ----------

dbutils.notebook.exit('success')