# Databricks notebook source
dbutils.widgets.text("p_data_source", "Testing", "Data Source:")
data_source = dbutils.widgets.get("p_data_source")

# COMMAND ----------

# MAGIC %run "../includes/configurations"

# COMMAND ----------

# MAGIC %run "../includes/common_functions"

# COMMAND ----------

from pyspark.sql.types import StructType, StructField, StringType, IntegerType, DoubleType, FloatType
from pyspark.sql.functions import current_timestamp, col, concat, lit

# COMMAND ----------

establish_sas_connection()

# COMMAND ----------

results_schema = StructType([
    StructField( "resultId", IntegerType(), False),
    StructField( "raceId", IntegerType(), True),
    StructField( "driverId", IntegerType(), True),
    StructField( "constructorId", IntegerType(), True),
    StructField( "number", IntegerType(), True),
    StructField( "grid", IntegerType(), True),
    StructField( "position", IntegerType(), True),
    StructField( "positionText", IntegerType(), True),
    StructField( "positionOrder", IntegerType(), True),
    StructField( "points", IntegerType(), True),
    StructField( "laps", IntegerType(), True),
    StructField( "time", StringType(), True),
    StructField( "milliseconds", IntegerType(), True),
    StructField( "fastestLap", IntegerType(), True),
    StructField( "rank", IntegerType(), True),
    StructField( "fastestLapTime", StringType(), True),
    StructField( "fastestLapSpeed", FloatType(), True),
    StructField( "statusId", IntegerType(), True)
])

# COMMAND ----------

results_df = spark.read.json(f"{raw_folder_path}/results.json", schema = results_schema)

results_df = results_df.withColumnRenamed("resultId", "result_id") \
    .withColumnRenamed("raceId", "race_id") \
    .withColumnRenamed("driverId", "driver_id") \
    .withColumnRenamed("constructorId", "constructor_id") \
    .withColumnRenamed("positionText", "position_text") \
    .withColumnRenamed("positionOrder", "position_order") \
    .withColumnRenamed("fastestLap", "fastest_lap") \
    .withColumnRenamed("fastestLapTime", "fastest_lap_time") \
    .withColumnRenamed("fastestLapSpeed", "fastest_lap_speed") \
    .withColumn("data_source", lit(data_source))

results_df = add_ingestion_datetime(results_df)

results_df = results_df.drop("statusId")

display(results_df)

# COMMAND ----------

results_df.write.mode("overwrite").partitionBy("race_id").parquet(f"{processed_folder_path}/results")

# COMMAND ----------

dbutils.notebook.exit('success')