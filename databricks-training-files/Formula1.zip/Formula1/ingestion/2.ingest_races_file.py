# Databricks notebook source
dbutils.widgets.text("p_data_source", "Testing", "Data Source:")
data_source = dbutils.widgets.get("p_data_source")

# COMMAND ----------

# MAGIC %run "../includes/configurations"

# COMMAND ----------

# MAGIC %run "../includes/common_functions"

# COMMAND ----------

from pyspark.sql.types import StructType, StructField, IntegerType, StringType, DoubleType, TimestampType, DateType

# COMMAND ----------

establish_sas_connection()

# COMMAND ----------

races_schema = StructType(fields=[StructField("raceId", IntegerType(), False),
                                     StructField("year", IntegerType(), True),
                                     StructField("round", IntegerType(), True),
                                     StructField("circuitId", IntegerType(), True),
                                     StructField("name", StringType(), True),
                                     StructField("date", StringType(), True),
                                     StructField("time", StringType(), True),
                                     StructField("url", StringType(), True)
])
races_df = spark.read \
.schema(races_schema) \
.csv(f"{raw_folder_path}/races.csv", header=True)
display(races_df)

# COMMAND ----------

from pyspark.sql.functions import *

# COMMAND ----------

renamed_races_df = races_df.withColumnRenamed("raceId", "race_id") \
.withColumnRenamed("year", "race_year") \
.withColumnRenamed("circuitId", "circuit_id") \
.withColumn("race_timestamp", try_to_timestamp(concat(col('date'), lit(' '), col('time')), lit('yyyy-MM-dd HH:mm:ss'))) \
.withColumn("data_source", lit(data_source))
final_races_df = renamed_races_df.drop("url").drop("date").drop("time")
final_races_df = add_ingestion_datetime(final_races_df)
# display(final_races_df)
# final_races_df.describe()
# races_df.describe()

# COMMAND ----------

final_races_df.write.mode("overwrite").partitionBy('race_year').parquet(f"{processed_folder_path}/races")

# COMMAND ----------

# MAGIC %fs
# MAGIC ls "abfss://processed@msdlformula1.dfs.core.windows.net/races"

# COMMAND ----------

dbutils.notebook.exit('success')