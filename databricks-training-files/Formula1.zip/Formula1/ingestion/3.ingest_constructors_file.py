# Databricks notebook source
dbutils.widgets.text("p_data_source", "Testing", "Data Source:")
data_source = dbutils.widgets.get("p_data_source")

# COMMAND ----------

# MAGIC %run "../includes/configurations"

# COMMAND ----------

# MAGIC %run "../includes/common_functions"

# COMMAND ----------

constructors_schema = """
  constructorId INT,
  constructorRef STRING,
  name STRING,
  nationality STRING,
  url STRING"""

# COMMAND ----------

establish_sas_connection()

# COMMAND ----------

from pyspark.sql.functions import current_timestamp, lit

# COMMAND ----------

constructors_df = spark.read.json(f"{raw_folder_path}/constructors.json", schema = constructors_schema)
constructors_df = constructors_df.drop("url")
constructors_df = constructors_df.withColumnRenamed("constructorId", "constructor_id") \
    .withColumnRenamed("constructorRef", "constructor_ref") \
    .withColumn("data_source", lit(data_source))
constructors_df = add_ingestion_datetime(constructors_df)
display(constructors_df)

# COMMAND ----------

constructors_df.write.mode("overwrite").parquet(f"{processed_folder_path}/constructors")

# COMMAND ----------

dbutils.notebook.exit('success')