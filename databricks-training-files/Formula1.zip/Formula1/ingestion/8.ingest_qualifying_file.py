# Databricks notebook source
dbutils.widgets.text("p_data_source", "Testing", "Data Source:")
data_source = dbutils.widgets.get("p_data_source")

# COMMAND ----------

# MAGIC %run "../includes/configurations"

# COMMAND ----------

# MAGIC %run "../includes/common_functions"

# COMMAND ----------

from pyspark.sql.types import StructType, StructField, StringType, IntegerType, DoubleType, FloatType
from pyspark.sql.functions import current_timestamp, lit

# COMMAND ----------

establish_sas_connection()

# COMMAND ----------

qualifying_schema = StructType([
    StructField( "qualifyId", IntegerType(), False),
    StructField( "raceId", IntegerType(), True),
    StructField( "driverId", IntegerType(), True),
    StructField( "constructorId", IntegerType(), True),
    StructField( "number", IntegerType(), True),
    StructField( "position", IntegerType(), True),
    StructField( "q1", StringType(), True),
    StructField( "q2", StringType(), True),
    StructField( "q3", StringType(), True)
])

# COMMAND ----------

qualifying_df = spark.read.option('multiLine', True).json(f"{raw_folder_path}/qualifying", schema = qualifying_schema)

qualifying_df = qualifying_df.withColumnRenamed("qualifyId", "qualify_id") \
    .withColumnRenamed("raceId", "race_id") \
    .withColumnRenamed("driverId", "driver_id") \
    .withColumnRenamed("constructorId", "constructor_id") \
    .withColumn("data_source", lit(data_source))

qualifying_df = add_ingestion_datetime(qualifying_df)

display(qualifying_df)

# COMMAND ----------

qualifying_df.write.mode("overwrite").parquet(f"{processed_folder_path}/qualifying")

# COMMAND ----------

display(spark.read.parquet(f"{processed_folder_path}/qualifying"))

# COMMAND ----------

dbutils.notebook.exit('success')