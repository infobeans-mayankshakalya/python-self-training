# Databricks notebook source
dbutils.widgets.text("p_data_source", "Testing", "Data Source:")
data_source = dbutils.widgets.get("p_data_source")

# COMMAND ----------

# MAGIC %run "../includes/configurations"

# COMMAND ----------

# MAGIC %run "../includes/common_functions"

# COMMAND ----------

from pyspark.sql.types import StructType, StructField, StringType, IntegerType, DoubleType, FloatType
from pyspark.sql.functions import current_timestamp, col, concat, lit

# COMMAND ----------

establish_sas_connection()

# COMMAND ----------

pit_stops_schema = StructType([
    StructField( "raceId", IntegerType(), False),
    StructField( "driverId", IntegerType(), True),
    StructField( "stop", IntegerType(), True),
    StructField( "lap", IntegerType(), True),
    StructField( "time", StringType(), True),
    StructField( "duration", FloatType(), True),
    StructField( "milliseconds", IntegerType(), True)
])

# COMMAND ----------

pit_stops_df = spark.read.option("multiLine", True).json(f"{raw_folder_path}/pit_stops.json", schema = pit_stops_schema)

pit_stops_df = pit_stops_df.withColumnRenamed("raceId", "race_id") \
    .withColumnRenamed("driverId", "driver_id") \
    .withColumn("data_source", lit(data_source))

pit_stops_df = add_ingestion_datetime(pit_stops_df)

pit_stops_df = pit_stops_df.drop("statusId")

display(pit_stops_df)

# COMMAND ----------

pit_stops_df.write.mode("overwrite").parquet(f"{processed_folder_path}/pit_stops")

# COMMAND ----------

dbutils.notebook.exit('success')