# Databricks notebook source
dbutils.widgets.text("p_data_source", "Testing", "Data Source:")
data_source = dbutils.widgets.get("p_data_source")

# COMMAND ----------

# MAGIC %run "../includes/configurations"

# COMMAND ----------

# MAGIC %run "../includes/common_functions"

# COMMAND ----------

from pyspark.sql.types import StructType, StructField, IntegerType, StringType, DoubleType

# COMMAND ----------

establish_sas_connection()

# COMMAND ----------

circuits_schema = StructType(fields=[StructField("circuitId", IntegerType(), False),
                                     StructField("circuitRef", StringType(), True),
                                     StructField("name", StringType(), True),
                                     StructField("location", StringType(), True),
                                     StructField("country", StringType(), True),
                                     StructField("lat", DoubleType(), True),
                                     StructField("lng", DoubleType(), True),
                                     StructField("alt", IntegerType(), True),
                                     StructField("url", StringType(), True)
])
circuits_df = spark.read \
.schema(circuits_schema) \
.csv(f"{raw_folder_path}/circuits.csv")
display(circuits_df)

# COMMAND ----------

from pyspark.sql.functions import current_timestamp, lit

# COMMAND ----------

renamed_circuits_df = circuits_df.withColumnRenamed("circuitId", "circuit_id") \
.withColumnRenamed("circuitRef", "circuit_ref") \
.withColumnRenamed("lat", "latitude") \
.withColumnRenamed("lng", "longitude") \
.withColumnRenamed("alt", "altitude") \
.withColumn("data_source", lit(data_source))
renamed_circuits_df = renamed_circuits_df.drop("url")
# display(renamed_circuits_df)
# from pyspark.sql.functions import current_timestamp
# final_circuits_df = renamed_circuits_df.withColumn("ingestion_date", current_timestamp())
final_circuits_df = add_ingestion_datetime(renamed_circuits_df)
display(final_circuits_df)

# COMMAND ----------

final_circuits_df.write.mode("overwrite").parquet(f"{processed_folder_path}/circuits")

# COMMAND ----------

# MAGIC %fs
# MAGIC ls "abfss://processed@msdlformula1.dfs.core.windows.net/circuits"

# COMMAND ----------

dbutils.notebook.exit('success')