# Databricks notebook source
from pyspark.sql.functions import current_timestamp
def add_ingestion_datetime( input_df ):
    output_df = input_df.withColumn("ingestion_datetime", current_timestamp())
    return output_df

def establish_sas_connection():
    client_id = dbutils.secrets.get(scope="Formula1Scope", key="MSDLFormula1ClientId")
    tenant_id = dbutils.secrets.get(scope="Formula1Scope", key="MSDLFormula1TenantId")
    client_secret = dbutils.secrets.get(scope="Formula1Scope", key="MSDLFormula1ClientSecret")

    spark.conf.set("fs.azure.account.auth.type.msdlformula1.dfs.core.windows.net", "OAuth")
    spark.conf.set("fs.azure.account.oauth.provider.type.msdlformula1.dfs.core.windows.net", "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider")
    spark.conf.set("fs.azure.account.oauth2.client.id.msdlformula1.dfs.core.windows.net", client_id)
    spark.conf.set("fs.azure.account.oauth2.client.secret.msdlformula1.dfs.core.windows.net", client_secret)
    spark.conf.set("fs.azure.account.oauth2.client.endpoint.msdlformula1.dfs.core.windows.net", f"https://login.microsoftonline.com/{tenant_id}/oauth2/token")