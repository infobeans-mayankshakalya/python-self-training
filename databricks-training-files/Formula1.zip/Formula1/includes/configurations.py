# Databricks notebook source
raw_folder_path = "abfss://raw@msdlformula1.dfs.core.windows.net"
processed_folder_path = "abfss://processed@msdlformula1.dfs.core.windows.net"
demo_folder_path = "abfss://demo@msdlformula1.dfs.core.windows.net"
presentation_folder_path = "abfss://presentation@msdlformula1.dfs.core.windows.net"