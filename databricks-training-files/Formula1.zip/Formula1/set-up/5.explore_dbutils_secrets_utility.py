# Databricks notebook source
# MAGIC %md
# MAGIC #Exploring the DBUtils Secrets Utility

# COMMAND ----------

dbutils.secrets.help()

# COMMAND ----------

dbutils.secrets.listScopes()

# COMMAND ----------

dbutils.secrets.list("Formula1Scope")

# COMMAND ----------

dbutils.secrets.get(scope="Formula1Scope", key="msdlFormula1AccountKey")