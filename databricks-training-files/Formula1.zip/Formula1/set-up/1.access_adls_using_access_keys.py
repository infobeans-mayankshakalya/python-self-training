# Databricks notebook source
secret_key = dbutils.secrets.get(scope="Formula1Scope", key="msdlFormula1AccountKey")

# COMMAND ----------

spark.conf.set(
    "fs.azure.account.key.msdlformula1.dfs.core.windows.net",
    secret_key
)

# COMMAND ----------

display(dbutils.fs.ls("abfss://demo@msdlformula1.dfs.core.windows.net"))

# COMMAND ----------

display(spark.read.csv('abfss://demo@msdlformula1.dfs.core.windows.net/circuits.csv'))