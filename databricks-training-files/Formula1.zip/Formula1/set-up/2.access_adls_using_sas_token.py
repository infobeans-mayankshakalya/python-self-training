# Databricks notebook source
sas_token = dbutils.secrets.get(scope="Formula1Scope", key="MSDLFormula1SASToken1")
# print(sas_token)

# COMMAND ----------

spark.conf.set("fs.azure.account.auth.type.msdlformula1.dfs.core.windows.net", "SAS")
spark.conf.set("fs.azure.sas.token.provider.type.msdlformula1.dfs.core.windows.net", "org.apache.hadoop.fs.azurebfs.sas.FixedSASTokenProvider")
spark.conf.set("fs.azure.sas.fixed.token.msdlformula1.dfs.core.windows.net", sas_token)

# COMMAND ----------

display(dbutils.fs.ls("abfss://demo@msdlformula1.dfs.core.windows.net"))

# COMMAND ----------

display(spark.read.csv('abfss://demo@msdlformula1.dfs.core.windows.net/circuits.csv'))